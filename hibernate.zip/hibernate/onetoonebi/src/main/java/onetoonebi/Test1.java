package onetoonebi;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Test1 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the aadharid:");
	int aid=sc.nextInt();
    EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
    EntityManager man=fac.createEntityManager();
    Query q=man.createQuery("select u from User where u.card.id=?1");
    q.setParameter(1,aid);
    try {
		User u=(User) q.getSingleResult();
	} catch (NoResultException e) {
		System.err.println("No info is found");
	}
    
}
}
