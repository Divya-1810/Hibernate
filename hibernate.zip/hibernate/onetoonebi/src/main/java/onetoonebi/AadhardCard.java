package onetoonebi;

import javax.persistence.OneToOne;

public class AadhardCard {
private int id;
private long aadharnumber;
private String address;
@OneToOne
private User u;
public User getU() {
	return u;
}
public void setU(User u) {
	this.u = u;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public long getAadharnumber() {
	return aadharnumber;
}
public void setAadharnumber(long aadharnumber) {
	this.aadharnumber = aadharnumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
@Override
public String toString() {
	return "AadhardCard [id=" + id + ", aadharnumber=" + aadharnumber + ", address=" + address + "]";
}

}
