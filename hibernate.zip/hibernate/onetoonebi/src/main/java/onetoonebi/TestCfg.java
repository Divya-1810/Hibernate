package onetoonebi;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestCfg {
public static void main(String[] args) {
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	System.out.println(fac);
//	EntityManager man=fac.createEntityManager();
//	EntityTransaction tran=man.getTransaction();
//	tran.begin();
//	
//	User u=new User();
//	u.setName("Divya");
//	u.setLocation("Tamilnadu");
//	
//	AadhardCard card=new AadhardCard();
//	card.setAadharnumber(123456789012l);
//	card.setAddress("Bangalore");
//	
//	tran.commit();
}
}
