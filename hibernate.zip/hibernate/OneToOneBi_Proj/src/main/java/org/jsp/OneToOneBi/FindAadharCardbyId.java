package org.jsp.OneToOneBi;
import java.util.Scanner;
import javax.persistence.*;
public class FindAadharCardbyId {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id:");
		int aid=sc.nextInt();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		AadharCard a=man.find(AadharCard.class,aid);
		if(a!=null) {
			System.out.println(a);
		}
		else {
			System.err.println("No user info is found");
		}
		
	}
	
}
