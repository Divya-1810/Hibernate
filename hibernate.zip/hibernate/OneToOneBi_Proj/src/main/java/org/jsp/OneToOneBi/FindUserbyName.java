package org.jsp.OneToOneBi;
import java.util.List;
import java.util.Scanner;
import javax.persistence.*;
public class FindUserbyName {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name:");
		String nm=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select u from User u where u.name=?1");
		q.setParameter(1,nm);
		List<User> u=q.getResultList();
		if(u.size()>0) {
			for (User user : u) {
				System.out.println(user);
			}
		}
		else {
			System.err.println("no user info found");
		}
	}
}
