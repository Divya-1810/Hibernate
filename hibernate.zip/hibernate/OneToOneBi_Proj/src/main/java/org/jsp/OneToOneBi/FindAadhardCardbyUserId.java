package org.jsp.OneToOneBi;
import java.util.Scanner;
import javax.persistence.*;
public class FindAadhardCardbyUserId {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id:");
		int id=sc.nextInt();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select a from AadharCard a where a.u.id=?1");
		q.setParameter(1,id);
		try {
			AadharCard a=(AadharCard) q.getSingleResult();
			System.out.println(a);
		} catch (NoResultException e) {
			System.err.println("no aadharcard info");
		}
	}
}
