package org.jsp.OneToOneBi;
import javax.persistence.*;
public class SaveUserAndAadharcard {
	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		EntityTransaction tran=man.getTransaction();
		tran.begin();
		
		User  u =new User();
		u.setName("Divya");
		u.setPhone(6381859158l);
		
		AadharCard card=new AadharCard();
		card.setNumber(556473219987l);
		card.setAddress("TamilNadu");
		card.setU(u);
		u.setCard(card);
		
		man.persist(u);
		
		tran.commit();
		
		}
}
