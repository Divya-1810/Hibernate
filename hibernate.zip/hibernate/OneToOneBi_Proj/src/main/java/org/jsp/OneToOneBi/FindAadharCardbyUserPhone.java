package org.jsp.OneToOneBi;
import java.util.Scanner;
import javax.persistence.*;
public class FindAadharCardbyUserPhone {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter phone:");
		long ph=sc.nextLong();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select a from AadharCard a where a.u.phone=?1");
		q.setParameter(1,ph);
		try {
			AadharCard a=(AadharCard) q.getSingleResult();
			System.out.println(a);
		} catch (NoResultException e) {
			System.err.println("no aadhar info");
		}
	}
}
