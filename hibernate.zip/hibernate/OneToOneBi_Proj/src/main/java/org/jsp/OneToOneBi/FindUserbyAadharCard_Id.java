package org.jsp.OneToOneBi;
import java.util.Scanner;
import javax.persistence.*;
public class FindUserbyAadharCard_Id {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter AadharCard_id:");
	int Aid=sc.nextInt();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select a.u from AadharCard a where a.id=?1");
	q.setParameter(1,Aid);
	try {
		User u=(User) q.getSingleResult();
		System.out.println(u);
	} catch (NoResultException e) {
		System.err.println("no user info");
	}
}
}
