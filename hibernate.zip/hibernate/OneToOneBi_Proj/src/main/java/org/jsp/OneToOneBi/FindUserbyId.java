package org.jsp.OneToOneBi;
import java.util.Scanner;

import javax.persistence.*;
public class FindUserbyId {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter id:");
	int uid=sc.nextInt();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	User u=man.find(User.class,uid);
	if(u!=null) {
		System.out.println(u);
	}
	else {
		System.err.println("No user info is found");
	}
	
}
}
