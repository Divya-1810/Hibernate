package org.jsp.OneToOneUni;
import java.util.Scanner;
import javax.persistence.*;
public class FindPersonById {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter id:");
	int pid=sc.nextInt();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Person p=man.find(Person.class,pid);
	if(p!=null) {
		System.out.println(p);
	}
	else {
		System.err.println("No Person info found since id is invalid");
	}
}
}
