package org.jsp.OneToOneUni;
import java.util.Scanner;
import javax.persistence.*;
public class FindPersonByPanCardNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the pancard number to find person info");
		String pnumber=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select p from Person p where p.card.number=?1");
		q.setParameter(1,pnumber);
		try {
			Person p=(Person) q.getSingleResult();
			System.out.println(p);
		} catch (NoResultException e) {
			System.err.println("No person info is found");
		}
	}
}
