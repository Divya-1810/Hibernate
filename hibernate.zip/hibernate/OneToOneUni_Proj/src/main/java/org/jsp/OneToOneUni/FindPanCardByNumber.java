package org.jsp.OneToOneUni;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FindPanCardByNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number:");
		String num=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select card from PanCard card where card.number=?1");
		q.setParameter(1,num);
		try {
			PanCard card=(PanCard) q.getSingleResult();
			System.out.println(card);
		} catch (NoResultException e) {
			System.err.println("No person info found since phone is invalid");
		}
	}
}
