package org.jsp.OneToOneUni;
import java.util.Scanner;
import javax.persistence.*;
public class FindPanCardByPersonId {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the person id to find pancard info");
	int pid=sc.nextInt();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select p.card from Person p where p.id=?1");
	q.setParameter(1,pid);
	try {
		PanCard card=(PanCard) q.getSingleResult();
		System.out.println(card);
	} catch (NoResultException e) {
		System.err.println("No pancard info is found");
	}
}
}
