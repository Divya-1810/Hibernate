package org.jsp.OneToOneUni;
import java.util.Scanner;
import javax.persistence.*;
public class FindPanCardByPersonPhone {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the phone");
	long phone=sc.nextLong();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select p.card from Person p where p.phone=?1");
	q.setParameter(1,phone);
	try {
		PanCard card=(PanCard) q.getSingleResult();
		System.out.println(card);
	} catch (NoResultException e) {
		System.err.println("No pancard info is found");
	}
}
}
