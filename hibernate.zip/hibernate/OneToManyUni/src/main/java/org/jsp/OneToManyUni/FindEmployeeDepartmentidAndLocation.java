package org.jsp.OneToManyUni;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FindEmployeeDepartmentidAndLocation {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter department id:");
		int did=sc.nextInt();
		System.out.println("Enter department location:");
		String dloc=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select d.emps from Department d where d.id=?1 and d.location=?2");
		q.setParameter(1,did);
		q.setParameter(2,dloc);
		List<Employee>lemps=q.getResultList();
		if(lemps.size()>0) {
			for (Employee employee : lemps) {
				System.out.println(employee);
			}
		}
		else {
			System.err.println("No info is found");
		}
		
	}
}
