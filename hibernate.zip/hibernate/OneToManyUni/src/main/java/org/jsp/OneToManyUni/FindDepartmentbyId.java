package org.jsp.OneToManyUni;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindDepartmentbyId {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter department id:");
	int did=sc.nextInt();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Department d=man.find(Department.class,did);
	if(d!=null) {
		System.out.println(d);
	}
	else {
		System.err.println("No Department info is found");
	}
}
}
