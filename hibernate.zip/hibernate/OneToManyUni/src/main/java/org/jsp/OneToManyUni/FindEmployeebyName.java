package org.jsp.OneToManyUni;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FindEmployeebyName {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee name:");
		String ename=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select e from Employee e where e.name=?1");
		q.setParameter(1,ename);
		List<Employee>ldp=q.getResultList();
		if(ldp.size()>0) {
			for (Employee employee : ldp) {
				System.out.println(employee);
			}
		}
		else {
			System.err.println("No info is found");
		}
		
	}
}
