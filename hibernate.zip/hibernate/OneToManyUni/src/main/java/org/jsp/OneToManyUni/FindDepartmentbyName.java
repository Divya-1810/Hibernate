package org.jsp.OneToManyUni;
import java.util.*;
import javax.persistence.*;
public class FindDepartmentbyName {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter department name:");
	String dname=sc.next();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select d from Department d where d.name=?1");
	q.setParameter(1,dname);
	List<Department>ldp=q.getResultList();
	if(ldp.size()>0) {
		for (Department department : ldp) {
			System.out.println(department);
		}
	}
	else {
		System.err.println("No info is found");
	}
	
}
}
