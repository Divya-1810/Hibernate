package org.jsp.OneToManyUni;

import java.util.Arrays;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class SaveDepartmentAndEmployee {
public static void main(String[] args) {
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
    EntityTransaction tran=man.getTransaction();
    tran.begin();
    
    Department d=new Department();
    d.setName("Training");
    d.setLocation("Bangalore");
    
    Employee e1=new Employee();
    e1.setName("Divya");
    e1.setDesg("Trainer");
    e1.setSalary(30000);
    
    
    Employee e2=new Employee();
    e2.setName("Sowmiya");
    e2.setDesg("Trainer");
    e2.setSalary(40000);
    
    
    Employee e3=new Employee();
    e3.setName("Dhanusri");
    e3.setDesg("Trainer");
    e3.setSalary(50000);
    
    d.setEmps(Arrays.asList(e1,e2,e3));
    
    man.persist(d);
    
    tran.commit();
    
    
}
}
