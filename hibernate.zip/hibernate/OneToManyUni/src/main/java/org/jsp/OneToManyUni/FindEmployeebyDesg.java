package org.jsp.OneToManyUni;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FindEmployeebyDesg {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee desg:");
		String edesg=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select e from Employee e where e.desg=?1");
		q.setParameter(1,edesg);
		List<Employee>ldp=q.getResultList();
		if(ldp.size()>0) {
			for (Employee employee : ldp) {
				System.out.println(employee);
			}
		}
		else {
			System.err.println("No info is found");
		}
		
	}
}
