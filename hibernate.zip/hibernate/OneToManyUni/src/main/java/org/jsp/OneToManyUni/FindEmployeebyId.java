package org.jsp.OneToManyUni;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FindEmployeebyId {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter employee id:");
		int eid=sc.nextInt();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Employee e=man.find(Employee.class,eid);
		if(e!=null) {
			System.out.println(e);
		}
		else {
			System.err.println("No Department info is found");
		}
	}
}
