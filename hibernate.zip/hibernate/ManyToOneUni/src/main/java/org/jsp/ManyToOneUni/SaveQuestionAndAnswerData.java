package org.jsp.ManyToOneUni;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class SaveQuestionAndAnswerData {
public static void main(String[] args) {
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	System.out.println(fac);
}
}
