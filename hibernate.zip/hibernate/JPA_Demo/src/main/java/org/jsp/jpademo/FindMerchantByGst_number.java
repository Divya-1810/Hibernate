package org.jsp.jpademo;

import java.util.*;
import javax.persistence.*;
public class FindMerchantByGst_number {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter the gst_number:");
	String gst=sc.next();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select m from Merchant m where m.gst_number=?1");
	q.setParameter(1,gst);
	List<Merchant>lg=q.getResultList();
	if(lg.size()>0) {
	   for (Merchant merchant : lg) {
		   System.out.println(merchant);
		}
	}
	else {
		System.err.println("No merchant info is found");
	}
}
}
