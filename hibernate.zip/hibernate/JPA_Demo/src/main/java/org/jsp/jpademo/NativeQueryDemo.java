package org.jsp.jpademo;

import java.util.List;

import javax.persistence.*;
public class NativeQueryDemo {
	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createNativeQuery("select * from Merchant",Merchant.class);
		List<Merchant> lm=q.getResultList();
		if(lm.size()>0) {
			for (Merchant merchant : lm) {
				System.out.println(merchant);
			}
		}
		else {
			System.err.println("No Merchant info is found");
		}
	}
}
//		List<Object[]> oarray=q.getResultList();
//		for (Object[] object : oarray) {
//			int id=(Integer) object[0];
//			String email=(String) object[1];
//			String gst_number=(String) object[2];
//			System.out.println("Merchant id"+id);
//			System.out.println("Merchant email"+email);
//			System.out.println("Merchant gst_number"+gst_number);
//			System.out.println("---------------------------------------");
//			
//		}
//}