package org.jsp.jpademo;

import java.util.*;
import javax.persistence.*;
public class FindMerchantByPhone {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter the phone number:");
			long ph=sc.nextLong();
			EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
			EntityManager man=fac.createEntityManager();
			Query q=man.createQuery("select m from Merchant m where m.phone=?1");
			q.setParameter(1,ph);
			List<Merchant>lp=q.getResultList();
			if(lp.size()>0) {
			   for (Merchant merchant : lp) {
				   System.out.println(merchant);
				}
			}
			else {
				System.err.println("No merchant info is found");
			}
		}
}
