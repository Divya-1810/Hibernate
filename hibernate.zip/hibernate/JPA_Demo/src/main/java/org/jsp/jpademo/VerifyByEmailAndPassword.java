package org.jsp.jpademo;
import java.util.Scanner;
import javax.persistence.*;
public class VerifyByEmailAndPassword {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter email:");
		String em=sc.next();
		System.out.println("enter password:");
		String pw=sc.next();
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select m from Merchant m where m.email=?1 and m.password=?2");
		q.setParameter(1,em);
		q.setParameter(2,pw);
		try {
			Merchant m=(Merchant) q.getSingleResult();
			System.out.println("Merchant is verified");
		} catch (NoResultException e) {
			System.err.println("No Merchant info is found");
		}
	}
}
