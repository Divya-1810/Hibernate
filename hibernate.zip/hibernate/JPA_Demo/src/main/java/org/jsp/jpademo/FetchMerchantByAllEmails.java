package org.jsp.jpademo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class FetchMerchantByAllEmails {
	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select m.email from Merchant m");
		List<String>em=q.getResultList();
		if(em.size()>0) {
		   for (String string : em) {
			System.out.println(string);
		}
		}
		else {
			System.err.println("No merchant info is found");
		}
	}
}
