package org.jsp.jpademo;
import java.util.List;
import javax.persistence.*;
public class FetchMerchantByGst_number {
public static void main(String[] args) {
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select m.gst_number from Merchant m");
	List<String>gst=q.getResultList();
	if(gst.size()>0) {
	   for (String string : gst) {
		System.out.println(string);
	}
	}
	else {
		System.err.println("No merchant info is found");
	}
}
}
