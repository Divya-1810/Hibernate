package org.jsp.jpademo;
import java.util.Scanner;
import javax.persistence.*;
public class verifybyPhoneAndPassword {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter phone number:");
	long ph=sc.nextLong();
	System.out.println("enter password:");
	String pw=sc.next();
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createQuery("select m from Merchant m where m.phone=?1 and m.password=?2");
	q.setParameter(1,ph);
	q.setParameter(2,pw);
	try {
		Merchant m=(Merchant) q.getSingleResult();
		System.out.println("Merchant is verified");
	} catch (NoResultException e) {
		System.err.println("No Merchant info is found");
	}
}
}
