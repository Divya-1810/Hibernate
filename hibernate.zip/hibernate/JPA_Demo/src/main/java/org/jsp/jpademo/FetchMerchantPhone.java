package org.jsp.jpademo;
import java.util.List;

import javax.persistence.*;
public class FetchMerchantPhone {
	public static void main(String[] args) {
		EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
		EntityManager man=fac.createEntityManager();
		Query q=man.createQuery("select m.phone from Merchant m");
		List<Long>lph=q.getResultList();
		if(lph.size()>0) {
		   for (Long long1 : lph) {
			   System.out.println(long1);
			}
		}
		else {
			System.err.println("No merchant info is found");
		}
}
}