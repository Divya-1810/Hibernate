package org.jsp.jpademo;
import javax.persistence.*;
import java.util.List;

public class NamedQueryDemo {
public static void main(String[] args) {
	EntityManagerFactory fac=Persistence.createEntityManagerFactory("dev");
	EntityManager man=fac.createEntityManager();
	Query q=man.createNamedQuery("fetchAllMerchants");
	List<Merchant> lm=q.getResultList();
	if(lm.size()>0) {
		for (Merchant merchant : lm) {
			System.out.println(merchant);
		}
	}
	else
	{
		System.err.println("merchant info is not found");
	}
}
}
