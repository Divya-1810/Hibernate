package org.jsp.hib;

public class Configuration {

}
