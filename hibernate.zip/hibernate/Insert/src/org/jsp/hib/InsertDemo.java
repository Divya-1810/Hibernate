package org.jsp.hib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
public class InsertDemo {
public static void main(String[] args) {
	Configuration conf=new Configuration();
	conf.configure();
	
}
}
