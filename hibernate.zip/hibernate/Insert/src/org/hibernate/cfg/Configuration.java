package org.hibernate.cfg;

public class Configuration {

}
