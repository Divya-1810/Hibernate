package org.hibernate;

public class Session {

}
